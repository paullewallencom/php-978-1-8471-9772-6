// declaring new variables
var date = new Date();
var hour = date.getHours();

// simple conditional output
if (hour >= 22 && hour <= 5) 
  document.write("You should go to sleep.");
else
  document.write("Hello, world!"); 
